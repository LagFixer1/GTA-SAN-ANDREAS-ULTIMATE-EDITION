---
name: Suggestion
about: Suggest an improvement or a mod for consideration
title: "[Suggestion]: "
labels: enhancement
assignees: ""
---

## Suggestion
Describe the improvement.

## Why would it help?
Explain the benefit to players or the project.

## Mod details (if applicable)
- Mod name:
- Original author:
- Official source:
- Dependencies:
- Known compatibility or performance concerns:
- Redistribution permissions or license:

## Additional context
Add any other useful details.
