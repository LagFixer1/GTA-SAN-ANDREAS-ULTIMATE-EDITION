---
name: Bug report
about: Report a reproducible problem with Ultimate Edition
title: "[Bug]: "
labels: bug
assignees: ""
---

## Summary
Describe the problem clearly.

## Game version
- GTA San Andreas version:
- Ultimate Edition version:
- Operating system:

## Steps to reproduce
1.
2.
3.

## Expected behavior
What did you expect to happen?

## Actual behavior
What happened instead?

## System details
Include relevant CPU, GPU, and RAM details if the issue may be hardware-related.

## Evidence
Add screenshots or logs if useful. Do not attach copyrighted game files or private information.

## Additional context
Any other details that may help reproduce the issue.
