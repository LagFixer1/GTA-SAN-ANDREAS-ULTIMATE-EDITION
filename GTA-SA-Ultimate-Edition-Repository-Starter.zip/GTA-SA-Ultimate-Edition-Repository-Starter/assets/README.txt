Place your original GTA SA: Ultimate Edition banner here as banner.png.
Place screenshots from the actual tested build in assets/screenshots/.
Only use artwork and screenshots you have permission to publish.
