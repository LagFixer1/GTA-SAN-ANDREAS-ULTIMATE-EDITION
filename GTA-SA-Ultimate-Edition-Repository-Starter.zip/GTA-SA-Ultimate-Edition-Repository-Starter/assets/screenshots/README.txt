Add screenshots captured from the actual modpack build here.
Suggested filenames: gameplay-01.png, gameplay-02.png, menu-01.png.
