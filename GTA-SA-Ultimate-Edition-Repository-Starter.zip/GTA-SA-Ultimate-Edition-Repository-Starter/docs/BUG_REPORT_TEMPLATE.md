# Bug report

- [ ] I checked the README and known issues.
- [ ] I can reproduce this issue.
- [ ] I have not included copyrighted game files or private information.

## Description

## Steps to reproduce

## Expected behavior

## Actual behavior

## Game and system version

## Screenshots or logs
